import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-exam',
  templateUrl: './select-exam.component.html',
  styleUrls: ['./select-exam.component.css']
})
export class SelectExamComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
